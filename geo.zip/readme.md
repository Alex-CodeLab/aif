



### Install

Create a venv & activate
    
    $ mkdir geo && cd geo 
    $ python -m venv env
    $ . env/bin/activate

install dependencies:

    $ pip install -r requirements.txt

### docker postgis
start the DB 

    $ docker-compose up


(check https://registry.hub.docker.com/r/postgis/postgis/ for more options)

### dev server

    $ cd geo
    $ ./manage.py migrate 
    $ ./manage.py runserver

url:
   http://127.0.0.1:8000/api/v1/features/?page=1


The migration  adds a default user.
This is only for dev/testing and should be replaced.

    username: admin
    password: 123 

### import data
The data importer requires the server to be active  

    $ python importer.py

### JWT

Get the tokens by visiting 

    http://127.0.0.1:8000/api/token/

or use 

    $ get_token.sh


### tests 
Test_data is availabale as a fixture.
The test-database imports data from fixtures/dumpdata_api.json

    $ ./manage.py tests




