from django.urls import path, re_path
from . import views


urlpatterns = [
    path('features/<int:pk>/', views.FeatureDetail.as_view(), name='feature-detail'),
    path('features/', views.FeaturesView.as_view(), name='features_pagination'),
    path('features/create/', views.create_data)

]