
from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
from rest_framework_gis.fields import GeoJsonDict
from rest_framework_simplejwt.tokens import AccessToken

from api.models import Feature
from api.serializers import FeatureSerializer


class FeatureTests(APITestCase):

    fixtures = ['api/fixtures/dumpdata_api.json', ]

    def setUp(self):
        """set auth token """
        user = User.objects.first()
        client = APIClient()
        token = AccessToken.for_user(user)
        client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
        self.client = client

    def test_getfeatures(self):
        """
        Ensure get the right feature(s)
        """
        url = 'https://localhost/api/v1/features/'
        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(response.data['count'] , 355)   # count all items in DB


    def test_features_pagination(self):
        """
        pagination
        """
        url = 'https://localhost/api/v1/features/?page=3'
        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(response.data['results']) , 100)   # make sure we only get 100 per page

        # check some item from page=3
        item= response.data['results'][0]
        self.assertEqual(item['id'], 201)
        self.assertEqual(item['name'], 'Asten')


    def test_pagination_out_of_range(self):
        """
        pagination out of range
        """
        url = 'https://localhost/api/v1/features/?page=9'
        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


    def test_getfeature_1(self):
        """
        check first 'feature' object
        """
        url = 'https://localhost/api/v1/features/1/'

        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(response.data['id'], 1)
        self.assertEqual(response.data['name'], 'Appingedam')
        self.assertEqual(type(response.data['geometry']),GeoJsonDict )
        geometry = response.data['geometry']
        self.assertEqual(geometry['type'], 'MultiPolygon')


    def test_feature_redirect_301(self):
        """
            '/' missing in url
        """
        url = 'https://localhost/api/v1/features/1'
        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_301_MOVED_PERMANENTLY)


    def test_feature_404(self):
        """
        request feature out of range
        """
        url = 'https://localhost/api/v1/features/4040/'

        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


    def test_create(self):
        """ Create new feature Object in DB """
        feature_data = {
            "name": "New Feature",
            "geometry": {
                "type": "MULTIPOLYGON",
                "coordinates":  [
                  [
                    [ [0, 0],
                      [0, 1],
                      [1, 1],
                      [1, 0],
                      [0, 0]
                    ]
                  ]
                ]
            }
        }

        url = 'https://localhost/api/v1/features/create/'

        response = self.client.post(url, data=feature_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        self.assertEqual(response.data['id'], 356)
        self.assertEqual(response.data['name'], 'New Feature')
        self.assertEqual(response.data['geometry']['type'], "MultiPolygon")


    def test_delete(self):
        url = 'https://localhost/api/v1/features/5/'
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        # check if really deleted
        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


    def test_update(self):
        feature = Feature.objects.get(pk=1)
        serializer_old = FeatureSerializer(feature)

        response = self.client.put(
            'https://localhost/api/v1/features/1/', data={'name': 'New Name', 'geometry': serializer_old.data['geometry']},
            format='json'
        )

        feature = Feature.objects.get(pk=1)
        serializer_new = FeatureSerializer(feature)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, serializer_new.data)
        self.assertEqual(response.data['name'], 'New Name')


    def test_boundingbox(self):
        url='http://localhost/api/v1/features/?min_lon=.1&min_lat=53&max_lon=5.9&max_lat=54'
        response = self.client.get(url, format='json')
        self.assertEqual(response.data['count'], 4)
        self.assertEqual(response.data['next'], None)


    def test_boundingbox_pages(self):
        url='http://localhost/api/v1/features/?min_lon=.1&min_lat=52&max_lon=6&max_lat=55'
        response = self.client.get(url, format='json')
        self.assertEqual(response.data['count'], 103)
        self.assertEqual(response.data['next'][-6:], 'page=2')
