from django.contrib.gis.geos import Polygon
from django.http import JsonResponse, Http404
from rest_framework import generics, status
from rest_framework.decorators import api_view
from rest_framework.filters import OrderingFilter
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Feature
from .serializers import FeatureSerializer


class FeaturesView(generics.ListAPIView):
    """list view Feature. """
    permission_classes = (IsAuthenticated,)
    serializer_class = FeatureSerializer
    filter_backends = [OrderingFilter]
    ordering  = ('id', )

    def get_queryset(self):
        min_lon = self.request.query_params.get('min_lon')
        min_lat = self.request.query_params.get('min_lat')
        max_lon = self.request.query_params.get('max_lon')
        max_lat = self.request.query_params.get('max_lat')

        if all([min_lon, min_lat, max_lon, max_lat]):
            bounding_box = Polygon.from_bbox((min_lon, min_lat, max_lon, max_lat))
            return Feature.objects.filter(
                geometry__within=bounding_box
            )
        return Feature.objects.all()

class FeatureDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Feature.objects.get(pk=pk)
        except Feature.DoesNotExist as e:
            raise Http404 from e

    def get(self, request, pk, format=None):
        if pk is None:
            raise Http404("URL requires id. ")
        feature = self.get_object(pk)
        serializer = FeatureSerializer(feature)
        return Response(serializer.data)

    def delete(self, request, pk):
        try:
            feature = Feature.objects.get(pk=pk)
            feature.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Feature.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def put(self, request, pk, format=None):
        snippet = self.get_object(pk)
        serializer = FeatureSerializer(snippet, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view([ 'POST'])
def create_data(request):
    if request.method == 'POST':
        serializer = FeatureSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
