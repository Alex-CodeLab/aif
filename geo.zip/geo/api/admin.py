from django.contrib import admin

from api.models import Feature

admin.site.register(Feature)