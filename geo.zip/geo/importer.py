import geopandas
import httpx

"""
 Import municipalities data and send to API
"""

def main():
    # API authentication
    auth_token = get_auth_token()
    if not auth_token:
        print("Authentication failed. Make sure the server is running: ./manage.py runserver")
        return

    headers = {"Authorization": f"Bearer {auth_token}"}
    # Import municipalities data and send POST requests
    gdf = geopandas.read_file('data/municipalities_nl.geojson')
    for index, row in gdf.iterrows():
        municipality_name = row['name']
        geometry = row['geometry']
        send_feature_data(municipality_name, geometry, headers)

def get_auth_token():
    url = 'http://localhost:8000/api/token/'
    headers = {'Content-Type': 'application/json'}
    data = {
        'username': 'admin',
        'password': '123'
    }
    response = httpx.post(url, headers=headers, json=data)
    return response.json().get('access') if response.status_code == 200 else None

def send_feature_data(name, geometry, headers):
    try:
        url = 'http://localhost:8000/api/v1/features/create/'
        data = {'name': name, 'geometry': geometry}
        response = httpx.post(url, data=data, headers=headers)
        if response.status_code == 201:
            print(f"Successfully created feature: {name}")
        else:
            print(f"Failed to create feature: {name}. Status code: {response.status_code}")
    except Exception as e:
        print(f"Error occurred while sending feature data: {e}")

if __name__ == "__main__":
    main()